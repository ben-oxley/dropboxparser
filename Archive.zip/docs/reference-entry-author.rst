.. _reference.entry.author:

:py:attr:`entries[i].author`
============================

The author of this entry.

.. seealso::

    * :ref:`reference.entry.author_detail`

.. rubric:: Comes from

* /atom10:feed/atom10:entry/atom10:author
* /atom03:feed/atom03:entry/atom03:author
* /rss/channel/item/dc:creator
* /rss/channel/item/dc:author
* /rss/channel/itunes:author
* /rdf:RDF/rdf:item/dc:creator
* /rdf:RDF/rdf:item/dc:author

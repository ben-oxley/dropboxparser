:py:attr:`feed`
===============

A dictionary of data about the feed.


.. rubric:: Comes from

* /atom03:feed
* /atom10:feed
* /rdf:RDF/rdf:channel
* /rss/channel


.. tip::

    This element always exists, although it may be an empty dictionary.
